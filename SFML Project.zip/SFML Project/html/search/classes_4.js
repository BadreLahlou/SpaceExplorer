var searchData=
[
  ['sorcerer_0',['Sorcerer',['../class_sorcerer.html',1,'']]],
  ['spriteobject_1',['SpriteObject',['../class_sprite_object.html',1,'']]],
  ['starttext_2',['StartText',['../class_start_text.html',1,'']]]
];
