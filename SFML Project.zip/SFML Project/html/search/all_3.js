var searchData=
[
  ['game_0',['Game',['../class_game.html',1,'']]],
  ['goblin_1',['Goblin',['../class_goblin.html',1,'']]]
];
